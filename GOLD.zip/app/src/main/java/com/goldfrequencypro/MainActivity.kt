package com.goldfrequencypro

import android.app.Activity
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private enum class Waveform(val label: String) {
        SINE("سینوسی"), SQUARE("مربعی"), SAWTOOTH("اره‌ای")
    }
    private val bg = Color.rgb(16, 17, 20)
    private val panel = Color.rgb(31, 33, 38)
    private val gold = Color.rgb(225, 181, 64)

    @Volatile private var frequencyA = 1000.0
    @Volatile private var frequencyB = 2000.0
    @Volatile private var amplitudeA = 0.25f
    @Volatile private var amplitudeB = 0.25f
    @Volatile private var waveformA = Waveform.SINE
    @Volatile private var waveformB = Waveform.SINE
    @Volatile private var scanEnabled = false
    private var scanStartedNanos = 0L
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    private val running = AtomicBoolean(false)

    private lateinit var rootLayout: LinearLayout
    private lateinit var pageContainer: LinearLayout
    private var currentPage = "خانه"
    private lateinit var frequencyTextA: TextView
    private lateinit var frequencyTextB: TextView
    private lateinit var statusText: TextView
    private lateinit var seekA: SeekBar
    private lateinit var seekB: SeekBar
    private lateinit var startButton: Button
    private lateinit var scanButton: Button
    private var selectedBankFrequency = 25.50

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(Color.rgb(8, 8, 10))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.mfad_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "لوگوی MFAD"
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)))
        val brand = TextView(this).apply {
            text = "GOLD FREQUENCY PRO\nنسخه 1.3  •  MFAD"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        header.addView(brand, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val menu = TextView(this).apply {
            text = "☰"
            textSize = 28f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setOnClickListener { showPage("تنظیمات") }
        }
        header.addView(menu, LinearLayout.LayoutParams(dp(42), dp(48)))
        rootLayout.addView(header, matchWrap())

        pageContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val scroll = ScrollView(this).apply { addView(pageContainer) }
        rootLayout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(5), dp(4), dp(5))
            setBackgroundColor(Color.rgb(7, 7, 9))
        }
        listOf("خانه" to "⌂", "اهداف" to "◎", "بانک" to "≋", "تنظیمات" to "⚙", "درباره" to "ⓘ").forEach { (name, symbol) ->
            val item = TextView(this).apply {
                text = "$symbol\n$name"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(gold)
                setPadding(dp(5), dp(5), dp(5), dp(5))
                setOnClickListener { showPage(name) }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, dp(54), 1f))
        }
        rootLayout.addView(nav, matchWrap())
        setContentView(rootLayout)
        showPage("خانه")
    }

    private fun showPage(page: String) {
        currentPage = page
        pageContainer.removeAllViews()
        when (page) {
            "خانه" -> buildHomePage()
            "اهداف" -> buildTargetsPage()
            "بانک" -> addFrequencyBank(pageContainer)
            "تنظیمات" -> buildSettingsPage()
            else -> buildAboutPage()
        }
    }

    private fun addSectionTitle(parent: LinearLayout, titleText: String) {
        val title = TextView(this).apply {
            text = titleText
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(14))
        }
        parent.addView(title, matchWrap())
    }

    private fun makeGoldButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(48, 39, 19), Color.rgb(9, 9, 11))
            ).apply {
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), gold)
            }
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { onClick() }
        }
    }

    private fun addPanel(parent: LinearLayout): LinearLayout {
        val panelView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(30, 28, 24), Color.rgb(10, 10, 12))
            ).apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.rgb(153, 112, 28))
            }
        }
        parent.addView(panelView, matchWrap().apply { bottomMargin = dp(12) })
        return panelView
    }

    private fun buildHomePage() {
        addSectionTitle(pageContainer, "پنل کنترل دستگاه")
        val hero = addPanel(pageContainer)
        val tagline = TextView(this).apply {
            text = "سامانه تولید سیگنال دوکاناله\nکنترل مستقل کانال A و B"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(12))
        }
        hero.addView(tagline, matchWrap())
        val values = TextView(this).apply {
            text = "کانال A: ${formatHz(frequencyA)} Hz     |     کانال B: ${formatHz(frequencyB)} Hz"
            textSize = 15f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        hero.addView(values, matchWrap())
        hero.addView(makeGoldButton("انتخاب هدف و فرکانس", { showPage("اهداف") }), matchWrap().apply { topMargin = dp(12) })

        val controls = addPanel(pageContainer)
        startButton = makeGoldButton("▶  شروع تولید دوکاناله", { if (running.get()) stopTone() else startTone() })
        controls.addView(startButton, matchWrap())
        scanButton = makeGoldButton("اسکن خودکار کانال A", {
            scanEnabled = !scanEnabled
            if (scanEnabled) {
                scanStartedNanos = System.nanoTime()
                scanButton.text = "توقف اسکن خودکار کانال A"
                statusText.text = "اسکن کانال A فعال است؛ کانال B مستقل می‌ماند"
            } else {
                scanButton.text = "اسکن خودکار کانال A"
                statusText.text = if (running.get()) "تولید دو کانال با فرکانس ثابت" else "متوقف"
            }
        })
        controls.addView(scanButton, matchWrap().apply { topMargin = dp(8) })
        statusText = TextView(this).apply {
            text = if (running.get()) "در حال تولید سیگنال" else "متوقف"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        controls.addView(statusText, matchWrap())
        val note = TextView(this).apply {
            text = "این برنامه مولد سیگنال صوتی آزمایشی است و به‌تنهایی فلز یا حفره را شناسایی نمی‌کند. نتیجه به سخت‌افزار و شرایط محیط وابسته است."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        pageContainer.addView(note, matchWrap())
    }

    private fun buildTargetsPage() {
        addSectionTitle(pageContainer, "انتخاب هدف")
        val targets = listOf(
            Triple("طلای اصلی اول", 5500.0, "5500 Hz"),
            Triple("طلای اصلی دوم", 612.0, "612.00 Hz"),
            Triple("نقره", 14500.0, "14500 Hz"),
            Triple("گنجینه", 14000.0, "14000 Hz"),
            Triple("فضای خالی / خلأ", 700.0, "700 Hz"),
            Triple("سفال", 725.0, "725 Hz"),
            Triple("استخوان", 16000.0, "16000 Hz"),
            Triple("سنگ‌های قیمتی", 18000.0, "18000 Hz"),
            Triple("قبر و مقبره", 17000.0, "17000 Hz"),
            Triple("چاه پلمپ‌شده", 12000.0, "12000 Hz")
        )
        targets.forEach { (name, hz, shown) ->
            val card = addPanel(pageContainer)
            val line = TextView(this).apply {
                text = "$name     •     $shown"
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(gold)
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(8))
            }
            card.addView(line, matchWrap())
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(makeGoldButton("اعمال روی A", { setFrequencyA(hz); showPage("تنظیمات") }), LinearLayout.LayoutParams(0, dp(48), 1f))
            actions.addView(makeGoldButton("اعمال روی B", { setFrequencyB(hz); showPage("تنظیمات") }), LinearLayout.LayoutParams(0, dp(48), 1f))
            card.addView(actions, matchWrap())
        }
    }

    private fun buildSettingsPage() {
        addSectionTitle(pageContainer, "تنظیمات خروجی و کانال‌ها")
        addChannelControls(pageContainer, "کانال A — خروجی چپ AUX (L)", true)
        addChannelControls(pageContainer, "کانال B — خروجی راست AUX (R)", false)
        val info = TextView(this).apply {
            text = "برای تفکیک دو کانال از کابل و ورودی استریو استفاده کنید. محدوده تنظیم دستی: ۱۰ تا ۲۰٬۰۰۰ هرتز."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        pageContainer.addView(info, matchWrap())
    }

    private fun buildAboutPage() {
        addSectionTitle(pageContainer, "درباره GOLD FREQUENCY PRO")
        val card = addPanel(pageContainer)
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.mfad_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        card.addView(logo, LinearLayout.LayoutParams(-1, dp(190)))
        val description = TextView(this).apply {
            text = "GOLD FREQUENCY PRO\nنسخه 1.3\n\nمولد سیگنال صوتی دوکاناله با کنترل مستقل فرکانس، شکل موج و شدت صدا.\n\nخروجی کانال A: چپ (L)\nخروجی کانال B: راست (R)"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        card.addView(description, matchWrap())
    }

    private fun addFrequencyBank(base: LinearLayout) {
        val bank = linkedMapOf(
            "طلا" to (listOf(5500.0,612.0,25.50,37.32,37.33,45.05,47.19,55.09,47.00,55.80,55.84,55.85,61.00,62.00,83.00,610.0,1006.0,1010.0,1013.0,1070.0,1106.0,1155.0,1325.0,1405.0,1418.0,1812.0,18000.0,59000.0)),
            "مس" to listOf(27.57,295.0,995.0,1090.0),
            "ذرات مس" to (4640..4647).map { it / 10.0 },
            "مفرق" to (4870..4879).map { it / 10.0 },
            "نقره" to listOf(42.55,466.0),
            "الماس" to listOf(45.01,550.0),
            "زمرد" to listOf(1247.0),
            "شیشه" to listOf(36.25),
            "آهن" to listOf(1761.0),
            "سفال" to listOf(725.0,91.75,488.0),
            "فضای خالی / خلأ" to listOf(700.0),
            "کربن" to listOf(39.05),
            "دندان" to listOf(710.0),
            "استخوان" to listOf(360.5,361.0,362.1,360.3),
            "آهنربا" to listOf(79.35,79.40,61.22,612.0,1080.0,1795.0,1797.0)
        )
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        base.addView(card, matchWrap().apply { topMargin = dp(14) })
        val heading = TextView(this).apply {
            text = "بانک کامل فرکانس‌های ثبت‌شده"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(gold); gravity = Gravity.CENTER
        }
        card.addView(heading, matchWrap())
        val category = Spinner(this)
        category.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bank.keys.toList())
        card.addView(category, matchWrap())
        val values = Spinner(this)
        fun refreshValues(index: Int) {
            val list = bank.values.elementAt(index)
            values.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                list.map { "${formatHz(it)} Hz" })
            selectedBankFrequency = list.first()
        }
        category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = refreshValues(position)
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        values.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedBankFrequency = bank.values.elementAt(category.selectedItemPosition)[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        card.addView(values, matchWrap())
        val applyA = Button(this).apply {
            text = "اعمال فرکانس انتخابی روی کانال A"
            setOnClickListener { setFrequencyA(selectedBankFrequency); statusText.text = "فرکانس بانک روی کانال A تنظیم شد" }
        }
        val applyB = Button(this).apply {
            text = "اعمال فرکانس انتخابی روی کانال B"
            setOnClickListener { setFrequencyB(selectedBankFrequency); statusText.text = "فرکانس بانک روی کانال B تنظیم شد" }
        }
        card.addView(applyA, matchWrap()); card.addView(applyB, matchWrap())
        val note = TextView(this).apply {
            text = "مقادیر بانک مطابق فهرست ثبت‌شده شما هستند. فرکانس‌های بالاتر از محدوده صوتی سخت‌افزار ممکن است از خروجی AUX قابل بازتولید دقیق نباشند؛ این بانک به معنی اثبات قابلیت شناسایی مواد نیست."
            textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, dp(8), 0, 0)
        }
        card.addView(note, matchWrap())
    }

    private fun formatHz(value: Double): String = if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()

    private fun addChannelControls(base: LinearLayout, title: String, isA: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        val cardLp = matchWrap().apply { topMargin = dp(12) }
        base.addView(card, cardLp)

        val heading = TextView(this).apply {
            text = title
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        card.addView(heading, matchWrap())

        val waveLabel = TextView(this).apply {
            text = "نوع موج ${if (isA) "کانال A" else "کانال B"}"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        card.addView(waveLabel, matchWrap())

        val waveSelector = Spinner(this).apply {
            val labels = Waveform.values().map { it.label }
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
            setSelection(if (isA) waveformA.ordinal else waveformB.ordinal)
            setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (isA) waveformA = Waveform.values()[position] else waveformB = Waveform.values()[position]
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            })
        }
        card.addView(waveSelector, matchWrap())

        val value = TextView(this).apply {
            text = "${formatHz(if (isA) frequencyA else frequencyB)} Hz"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        card.addView(value, matchWrap())
        if (isA) frequencyTextA = value else frequencyTextB = value

        val range = TextView(this).apply {
            text = "فرکانس مستقل: ۱۰ تا ۲۰٬۰۰۰ هرتز"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        card.addView(range, matchWrap())

        val freqSeek = SeekBar(this).apply {
            max = 19990
            progress = ((if (isA) frequencyA else frequencyB) - 10).toInt().coerceIn(0, 19990)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val hz = 10 + p
                        if (isA) setFrequencyA(hz.toDouble()) else setFrequencyB(hz.toDouble())
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        card.addView(freqSeek, matchWrap())
        if (isA) seekA = freqSeek else seekB = freqSeek

        val volLabel = TextView(this).apply {
            text = "شدت صدای ${if (isA) "کانال A" else "کانال B"}"
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        card.addView(volLabel, matchWrap())
        val volume = SeekBar(this).apply {
            max = 80
            progress = 25
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (isA) amplitudeA = (p / 100f).coerceIn(0f, 0.8f)
                    else amplitudeB = (p / 100f).coerceIn(0f, 0.8f)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        card.addView(volume, matchWrap())
    }

    private fun setFrequencyA(hz: Double) {
        scanEnabled = false
        if (::scanButton.isInitialized) scanButton.text = "شروع اسکن خودکار کانال A"
        frequencyA = hz
        if (::frequencyTextA.isInitialized) frequencyTextA.text = "${formatHz(frequencyA)} Hz"
        if (::seekA.isInitialized) seekA.progress = (frequencyA - 10).toInt().coerceIn(0, 19990)
    }

    private fun setFrequencyB(hz: Double) {
        frequencyB = hz
        if (::frequencyTextB.isInitialized) frequencyTextB.text = "${formatHz(frequencyB)} Hz"
        if (::seekB.isInitialized) seekB.progress = (frequencyB - 10).toInt().coerceIn(0, 19990)
    }

    private fun startTone() {
        if (running.get()) return
        val sampleRate = 48000
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            statusText.text = "خطا در راه‌اندازی خروجی استریو"
            return
        }
        val bufferSize = maxOf(minBuffer, 8192)
        val audio = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        track = audio
        running.set(true)
        startButton.text = "توقف تولید دوکاناله"
        statusText.text = "کانال A چپ و کانال B راست در حال پخش هستند"
        audio.play()

        worker = Thread {
            val frames = 2048
            val samples = ShortArray(frames * 2)
            var phaseA = 0.0
            var phaseB = 0.0
            var lastUiUpdate = 0L
            while (running.get()) {
                if (scanEnabled) {
                    val elapsed = ((System.nanoTime() - scanStartedNanos) / 1_000_000_000.0) % 20.0
                    val fraction = if (elapsed <= 10.0) elapsed / 10.0 else (20.0 - elapsed) / 10.0
                    frequencyA = 10000.0 + fraction * 10000.0
                    val now = System.nanoTime()
                    if (now - lastUiUpdate >= 100_000_000L) {
                        val shown = frequencyA
                        runOnUiThread {
                            if (scanEnabled) {
                                if (::frequencyTextA.isInitialized && ::seekA.isInitialized) {
                                    frequencyTextA.text = "${formatHz(shown)} Hz"
                                    seekA.progress = (shown - 10).toInt().coerceIn(0, 19990)
                                }
                            }
                        }
                        lastUiUpdate = now
                    }
                }

                val hzA = frequencyA
                val hzB = frequencyB
                val ampA = amplitudeA
                val ampB = amplitudeB
                val shapeA = waveformA
                val shapeB = waveformB
                val stepA = 2.0 * PI * hzA / sampleRate
                val stepB = 2.0 * PI * hzB / sampleRate
                for (i in 0 until frames) {
                    samples[i * 2] = (waveValue(phaseA, shapeA) * ampA * Short.MAX_VALUE)
                        .toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort() // Left: A
                    samples[i * 2 + 1] = (waveValue(phaseB, shapeB) * ampB * Short.MAX_VALUE)
                        .toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort() // Right: B
                    phaseA += stepA
                    phaseB += stepB
                    if (phaseA >= 2.0 * PI) phaseA -= 2.0 * PI
                    if (phaseB >= 2.0 * PI) phaseB -= 2.0 * PI
                }
                try { audio.write(samples, 0, samples.size) } catch (_: Exception) { break }
            }
        }.also { it.start() }
    }

    private fun waveValue(phase: Double, shape: Waveform): Double = when (shape) {
        Waveform.SINE -> sin(phase)
        Waveform.SQUARE -> if (phase < PI) 1.0 else -1.0
        Waveform.SAWTOOTH -> (phase / PI) - 1.0
    }

    private fun stopTone() {
        running.set(false)
        try { worker?.join(300) } catch (_: InterruptedException) {}
        worker = null
        try { track?.pause(); track?.flush(); track?.stop(); track?.release() } catch (_: Exception) {}
        track = null
        if (::startButton.isInitialized) startButton.text = "شروع تولید دوکاناله"
        if (::statusText.isInitialized) statusText.text = if (scanEnabled) "اسکن آماده است؛ برای شنیدن خروجی شروع را بزنید" else "متوقف"
    }

    override fun onPause() {
        scanEnabled = false
        if (::scanButton.isInitialized) scanButton.text = "شروع اسکن خودکار کانال A"
        stopTone()
        super.onPause()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
